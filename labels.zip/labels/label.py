import h5py
hdfSourceFile = '../modelnet/test0.h5'
with h5py.File(hdfSourceFile, 'r') as source: 
    data = source['label']
    for count, row in enumerate(data): 
        with open(f'label_{str(count)}.txt', 'w') as textfile:
            textfile.write(f"{str(row[0])}")

# data = h5py.File(hdfSourceFile,'r')
# print(data['label'][0][0])